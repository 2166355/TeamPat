<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="styles.css">
        <title>Webtech Quiz</title>
    </head>
    <body>


    <div id="wrapper">
    <h1>Webtech Quiz</h1>
    <form id="quiz" action="./review.php" method="post">

        <?php
        $p = $_POST["posts"];
        $posts = unserialize(base64_decode($p));
        $qnum = $_POST["qNum"];

        ?>

        <p id = "question"></p>
        <input type = "text" name = "ans" id = "ans" onfocus="this.value=''" placeholder="" ><br>
        <br><div id = "prev"></div>
        <div id = "next"><button type = "button" id = "nextB" onclick="nextQ()" >Next</button></div>
        <input type = "hidden" name = "qNum" value = "<?php echo $qnum?>">
        <div id = "hidn"></div>
        <div id = "subm"></div>

        <script type="text/javascript">
            var obj = JSON.parse('<?php echo json_encode($posts) ?>');
            var counter = 0;
            document.getElementById("question").innerHTML = obj[counter].qNum +". "+ obj[counter].question+". "; 
            var cont = [];
            var ps;
            console.log(obj);
            function nextQ(){
                if(!document.getElementById("prevbtn")){
                    var para = document.createElement("BUTTON");
                    para.setAttribute("id","prevbtn");
                    para.setAttribute('type', 'button');
                    para.onclick = function () {
                        if (counter == 1){
                            document.getElementById("prevbtn").disabled = true;
                        }else{
                            document.getElementById("prevbtn").disabled = false;
                        }
                        counter = counter -= 1;
                        cont.splice(counter);
                        document.getElementById("question").innerHTML = obj[counter].qNum +". "+ obj[counter].question+". "; };
                        document.getElementById("ans").innerHTML = '';
                    var text = document.createTextNode("Previous");
                    para.appendChild(text);
                    var n = document.getElementById("prev");
                    n.appendChild(para);
                    ps = document.getElementById("ans").value;
                }
                if(counter< <?php echo $qnum?>-1){
                    document.getElementById("prevbtn").disabled = false;
                    document.getElementById("ans").innerHTML = '';
                    counter = counter += 1;
                    document.getElementById("question").innerHTML = obj[counter].qNum +". "+ obj[counter].question+". ";
                    ps = document.getElementById("ans").value;
                    cont.push(ps);
                }else {
                    document.getElementById("prevbtn").disabled = false;
                    document.getElementById("ans").innerHTML = '';
                    counter = counter += 1;
                    ps = document.getElementById("ans").value;
                    cont.push(ps); 
                    var h = document.createElement("INPUT");
                    h.setAttribute("id","hidans");
                    h.setAttribute("name","hidans");
                    h.setAttribute("type", "hidden");
                    h.setAttribute("value", "<?php print base64_encode(serialize($posts)) ?>");
                    var hie = document.getElementById("hidn");
                    hie.appendChild(h);

                    var a = document.createElement("INPUT");
                    a.setAttribute("id","hans");
                    a.setAttribute("name","hans");
                    a.setAttribute("type", "hidden");
                    a.setAttribute("value", JSON.stringify(cont));
                    var aie = document.getElementById("hidn");
                    aie.appendChild(a);

                    if (confirm("Are you sure you want to submit your answers?")) {
                        if(cont.includes("")){
                            var z = 0;
                            for(var cout = 0; cout < cont.length; cout++){
                                if(cont[cout] == ""){
                                    z = z+=1;
                                }
                            }
                            if(confirm("You have no answer in item(s) "+z+". Continue?")){
                                document.getElementById("prevbtn").disabled = true;
                                document.getElementById("nextB").disabled = true;
                                var sub = document.createElement("INPUT");
                                var tsub = document.createTextNode("Submit");
                                sub.appendChild(tsub);
                                sub.setAttribute("id","subbtn");
                                sub.setAttribute("type", "submit");
                                var s = document.getElementById("subm");
                                s.appendChild(sub);
                            }
                        }else{
                            document.getElementById("prevbtn").disabled = true;
                            document.getElementById("nextB").disabled = true;
                            var sub = document.createElement("INPUT");
                            var tsub = document.createTextNode("Submit");
                            sub.appendChild(tsub);
                            sub.setAttribute("id","subbtn");
                            sub.setAttribute("type", "submit");
                            var s = document.getElementById("subm");
                            s.appendChild(sub);
                        }
                    }
                }
            }

        </script> 

    </form> 

    </body>
</html>
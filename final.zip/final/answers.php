<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="styles.css">
        <title>Webtech Quiz</title>
    </head>
    <body>

    <div id="wrapper2">
    <h1>Webtech Quiz</h1>
    <div id = "content">
    </div>
    <br>
    <div id = "score"></div>
    <div>
    <br>
        <button id="tryagain" onclick="window.location.href='./ask'">Try Again?</button>
        <button id="gtHome" onclick="window.location.href='./home'">Go to home</button>
    </div>
    <?php 

        $qs = $_POST["hidans"];
        $qn = $_POST["qNum"];
        $q = unserialize(base64_decode($qs));      

        $as1 = $_POST["hans"]; 
        $as = unserialize(base64_decode($as1));  

    ?>
    <script type="text/javascript">
        var score = 0;
        var b = <?php echo json_encode($q)?>;
        var d = <?php echo $as?>;
        for(var x = 0; x< <?php echo $qn?>;x++){
            var createDiv = document.createElement("div");
            createDiv.setAttribute("id","divcont");

            var q1 = document.createElement("p");
            var c = document.createTextNode(b[x].qNum+": "+b[x].question);
            q1.appendChild(c);

            createDiv.appendChild(q1);

            var q2 = document.createElement("p");
            var ca = document.createTextNode("Correct answer: "+b[x].answer);
            q2.appendChild(ca);
            createDiv.appendChild(q2);

            var q3 = document.createElement("p");
            var da = document.createTextNode("Your answer: "+d[x]);
            q3.appendChild(da);
            createDiv.appendChild(q3);

            document.getElementById("content").appendChild(createDiv);

            if(b[x].answer.toUpperCase().trim()==d[x].toUpperCase().trim()){
                score = score+= 1;
                createDiv.setAttribute("style", "background-color:#5cdb5c");
            }else{
                createDiv.setAttribute("style", "background-color:#ff8484");
            }
            
        }
        document.getElementById("score").innerHTML = "You got: "+score +"/"+ <?php echo $qn?>;
        
    </script>
    </body>
</html>
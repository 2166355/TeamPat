<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="styles.css">
        <title>Webtech Quiz</title>
    </head>
    <body>

    <div id="wrapper">
    <h1>Webtech Quiz</h1>
    <form id="quiz" action="./quiz.php" method="post">

        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "webtech";
        
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
        $qnum1 = $_POST["qNum"];
        $qnum1 = (int)$qnum1;
        $sql = 'SELECT qID,qtype,question,answer FROM ' .$_POST["qtopic"]. ' where qtype = "FitB" order by RAND() LIMIT '.$qnum1;
        $result = $conn->query($sql);
        echo '<input type = "hidden" name = "qNum" value = "'.$qnum1.'">';
        if ($result->num_rows > 0) {
            $counter = 1;
            $posts = array();
            while($row = $result->fetch_assoc()) {
                    $qnum = $counter;
                    $question = $row["question"];
                    $ans = $row["answer"];
                    $posts[] = array('qNum'=> $qnum,'question' => $question, 'answer'=> $ans);
                $counter = $counter+1;
            }
        } else {
            echo "0 results";
        }
        $conn->close();
        ?>

        <input type = "hidden" name = "posts" value = "<?php print base64_encode(serialize($posts)) ?>">
        <input type = "submit" id="submit2" value = "Start Quiz">
    </form> 
</div>
    </body>
</html>